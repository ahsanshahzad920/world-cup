<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentUserResponse extends Model
{
    protected $table = 'document_user_responses';
    protected $guarded = [];
}
