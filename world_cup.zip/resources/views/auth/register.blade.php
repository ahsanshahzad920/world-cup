@extends('layouts.app')

@section('content')

{{--<form action="{{ route('register') }}" method="POST">
    @csrf
    <a href="/" class="ad-auth-logo">
         <h4 class="text-center">TRAMEC</h4>
    </a>
    <h2><span class="primary">Hello,</span>Welcome!</h2>
    <p>Please Enter Your Details Below to Continue</p>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="ad-auth-form">
        <div class="ad-auth-feilds mb-30">
            <input type="text" placeholder="First Name" class="ad-input" name="first_name" value="{{ old('first_name') }}" />
            <div class="ad-auth-icon">
                <svg 
                 xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink"
                 width="16px" height="16px">
                <path fill-rule="evenodd"  fill="rgb(154, 190, 237)"
                 d="M13.696,9.759 C12.876,8.942 11.901,8.337 10.837,7.971 C11.989,7.180 12.742,5.850 12.725,4.349 C12.698,1.961 10.713,0.031 8.318,0.062 C5.946,0.093 4.026,2.026 4.026,4.398 C4.026,5.879 4.774,7.189 5.914,7.971 C4.850,8.337 3.875,8.942 3.055,9.759 C1.786,11.025 1.026,12.663 0.878,14.426 C0.849,14.768 1.117,15.063 1.462,15.063 L1.466,15.063 C1.772,15.063 2.024,14.827 2.050,14.523 C2.325,11.285 5.057,8.734 8.375,8.734 C11.694,8.734 14.425,11.285 14.701,14.523 C14.727,14.827 14.979,15.063 15.285,15.063 L15.289,15.063 C15.634,15.063 15.902,14.768 15.873,14.426 C15.725,12.663 14.965,11.025 13.696,9.759 ZM8.375,7.562 C6.625,7.562 5.201,6.143 5.201,4.398 C5.201,2.653 6.625,1.234 8.375,1.234 C10.126,1.234 11.550,2.653 11.550,4.398 C11.550,6.143 10.126,7.562 8.375,7.562 Z"/>
                </svg>
            </div>
        </div>
        <div class="ad-auth-feilds mb-30">
            <input type="text" placeholder="Last Name" class="ad-input" name="last_name" value="{{ old('last_name') }}" />
            <div class="ad-auth-icon">
                <svg 
                 xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink"
                 width="16px" height="16px">
                <path fill-rule="evenodd"  fill="rgb(154, 190, 237)"
                 d="M13.696,9.759 C12.876,8.942 11.901,8.337 10.837,7.971 C11.989,7.180 12.742,5.850 12.725,4.349 C12.698,1.961 10.713,0.031 8.318,0.062 C5.946,0.093 4.026,2.026 4.026,4.398 C4.026,5.879 4.774,7.189 5.914,7.971 C4.850,8.337 3.875,8.942 3.055,9.759 C1.786,11.025 1.026,12.663 0.878,14.426 C0.849,14.768 1.117,15.063 1.462,15.063 L1.466,15.063 C1.772,15.063 2.024,14.827 2.050,14.523 C2.325,11.285 5.057,8.734 8.375,8.734 C11.694,8.734 14.425,11.285 14.701,14.523 C14.727,14.827 14.979,15.063 15.285,15.063 L15.289,15.063 C15.634,15.063 15.902,14.768 15.873,14.426 C15.725,12.663 14.965,11.025 13.696,9.759 ZM8.375,7.562 C6.625,7.562 5.201,6.143 5.201,4.398 C5.201,2.653 6.625,1.234 8.375,1.234 C10.126,1.234 11.550,2.653 11.550,4.398 C11.550,6.143 10.126,7.562 8.375,7.562 Z"/>
                </svg>
            </div>
        </div>
        <div class="ad-auth-feilds mb-30">
            <input type="text" placeholder="Email Address" class="ad-input" name="email" value="{{ old('email') }}" />
            <div class="ad-auth-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 483.3 483.3"><path d="M424.3,57.75H59.1c-32.6,0-59.1,26.5-59.1,59.1v249.6c0,32.6,26.5,59.1,59.1,59.1h365.1c32.6,0,59.1-26.5,59.1-59.1    v-249.5C483.4,84.35,456.9,57.75,424.3,57.75z M456.4,366.45c0,17.7-14.4,32.1-32.1,32.1H59.1c-17.7,0-32.1-14.4-32.1-32.1v-249.5    c0-17.7,14.4-32.1,32.1-32.1h365.1c17.7,0,32.1,14.4,32.1,32.1v249.5H456.4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#9abeed"></path><path d="M304.8,238.55l118.2-106c5.5-5,6-13.5,1-19.1c-5-5.5-13.5-6-19.1-1l-163,146.3l-31.8-28.4c-0.1-0.1-0.2-0.2-0.2-0.3    c-0.7-0.7-1.4-1.3-2.2-1.9L78.3,112.35c-5.6-5-14.1-4.5-19.1,1.1c-5,5.6-4.5,14.1,1.1,19.1l119.6,106.9L60.8,350.95    c-5.4,5.1-5.7,13.6-0.6,19.1c2.7,2.8,6.3,4.3,9.9,4.3c3.3,0,6.6-1.2,9.2-3.6l120.9-113.1l32.8,29.3c2.6,2.3,5.8,3.4,9,3.4    c3.2,0,6.5-1.2,9-3.5l33.7-30.2l120.2,114.2c2.6,2.5,6,3.7,9.3,3.7c3.6,0,7.1-1.4,9.8-4.2c5.1-5.4,4.9-14-0.5-19.1L304.8,238.55z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#9abeed"></path></svg>
            </div>
        </div>
        <div class="ad-auth-feilds">
            <input type="password" placeholder="Password" class="ad-input" name="password" />
            <div class="ad-auth-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 482.8 482.8"><path d="M395.95,210.4h-7.1v-62.9c0-81.3-66.1-147.5-147.5-147.5c-81.3,0-147.5,66.1-147.5,147.5c0,7.5,6,13.5,13.5,13.5    s13.5-6,13.5-13.5c0-66.4,54-120.5,120.5-120.5c66.4,0,120.5,54,120.5,120.5v62.9h-275c-14.4,0-26.1,11.7-26.1,26.1v168.1    c0,43.1,35.1,78.2,78.2,78.2h204.9c43.1,0,78.2-35.1,78.2-78.2V236.5C422.05,222.1,410.35,210.4,395.95,210.4z M395.05,404.6    c0,28.2-22.9,51.2-51.2,51.2h-204.8c-28.2,0-51.2-22.9-51.2-51.2V237.4h307.2L395.05,404.6L395.05,404.6z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#9abeed"></path><path d="M241.45,399.1c27.9,0,50.5-22.7,50.5-50.5c0-27.9-22.7-50.5-50.5-50.5c-27.9,0-50.5,22.7-50.5,50.5    S213.55,399.1,241.45,399.1z M241.45,325c13,0,23.5,10.6,23.5,23.5s-10.5,23.6-23.5,23.6s-23.5-10.6-23.5-23.5    S228.45,325,241.45,325z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#9abeed"></path></svg>
            </div>
        </div>
    </div>
    
    <div class="ad-auth-btn">
        <input type="submit" class="ad-btn ad-login-member" value="Sign up" />
    </div>
    <p class="ad-register-text">Already have an account ? <a href="{{ route('login') }}">Login</a></p>
</form>--}}
<!--  -->

<div class="sign-up-form my-5">
        <div class="container">
            <h1 class="text-center main-heading light-green-color py-4">Sign Up</h1>
            <div class="col-sm-12 col-md-10-off-set-1 col-lg-8 offset-lg-2">
            <form action="{{ route('register') }}" method="POST" class="p-4" enctype="multipart/form-data">
                @csrf
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name<span class="text-danger">*</span> </label>
                        <input type="text" placeholder="First Name" class="form-control" name="first_name" value="{{ old('first_name') }}" />
                        
                    </div>
                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name<span class="text-danger">*</span> </label>
                        <input type="text" placeholder="Last Name" class="form-control" name="last_name" value="{{ old('last_name') }}" />
                    </div>
                    <div class="mb-3">
                        <label for="phoneNumber" class="form-label">Phone Number<span class="text-danger">*</span>
                        </label>
                        <input type="text" placeholder="Phone Number" class="form-control" name="phone" value="{{ old('phone') }}" />
                    </div>
                    <div class="mb-3">
                        <label for="emailAddress" class="form-label">Email Address<span
                                class="text-danger">*</span></label>
                                <input type="email" placeholder="Email Address" class="form-control" name="email" value="{{ old('email') }}" />
                    </div>
                    <div class="mb-3">
                        <label for="emailAddress" class="form-label">Password<span
                                class="text-danger">*</span></label>
                                <input type="password" placeholder="" class="form-control" name="password" value="{{ old('password') }}" />
                    </div>
                    <div class="mb-3">
                        <label for="nickName" class="form-label">Nick Name<span class="text-danger">*</span> </label>
                        <input type="text" placeholder="Nick Name" class="form-control" name="nickname" value="{{ old('nickname') }}" />
                    </div>
                    <div class="mb-3">
                        <label for="formFile" class="form-label">Upload an image (optional) – default image will be
                            displayed otherwise</label>
                        <input class="form-control" type="file" id="formFile" name="image">
                    </div>
                    <div class="mb-3">
                        <label for="whatsAppDiscussion" class="form-label">Do you want to participate in the WhatsApp
                            Discussion throughout the tournament? (Please note that carrier fees may apply dependent on
                            your plan).<span class="text-danger">*</span></label>
                        <input type="radio" name="whatsAppDiscussion" value="yes"> Yes
                        <input type="radio" name="whatsAppDiscussion" value="no" class="ms-3"> No
                    </div>
                    <div class="mb-3">
                        <label for="termsAndConditions" class="form-label">Agree to <a href="#">Terms & Conditions</a>
                            (if “no” submission is cancelled.)<span class="text-danger">*</span></label><br>
                        <input type="radio" name="termsAndConditions" value="yes" > Yes
                        <input type="radio" name="termsAndConditions" value="no" class="ms-3"> No
                    </div>
                    <button type="submit" class="btn btn-success">Create Account</button>
                </form>
            </div>
        </div>
    </div>
@endsection