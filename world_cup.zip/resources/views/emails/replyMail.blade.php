<!DOCTYPE html>
<html>
<head>
    <title>Futebol Fanatics Platform</title>
</head>
<body>
    <b>Hi,</b><br>
    <p>{{ $details['body'] }}</p>
   
</body>
</html>