@extends('layouts.admin')

@section('content')
<div>
                    <h3>Dashboard Content Here...</h3>
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <canvas id="myChart" style="height: 400px;width: 100%;" aria-label="chart"></canvas>
                        </div>
                        <div class="col-12 col-md-6">
                            <canvas id="myChart2" style="height: 400px;width: 100%;" aria-label="chart"></canvas>
                        </div>
                    </div>
                </div>
@endsection